/**
 * @version 1.0.0.0
 * @copyright Copyright ©  2020
 * @compiler Bridge.NET 17.10.1
 */
Bridge.assembly("FVTTBridge", function ($asm, globals) {
    "use strict";

    Bridge.define("FVTTBridge.Bindings.FoundrySystem", {
        statics: {
            fields: {
                Instance: null
            }
        },
        props: {
            ActorType: {
                get: function () {
                    return FVTTBridge.BridgeActor;
                }
            },
            ActorSheetType: {
                get: function () {
                    return FVTTBridge.BridgeActorSheet;
                }
            }
        },
        ctors: {
            ctor: function () {
                this.$initialize();
                FVTTBridge.Bindings.FoundrySystem.Instance = this;
                Hooks.once("init", Bridge.fn.cacheBind(this, this.SystemInit));
            }
        },
        methods: {
            MakeActor: function (glue) {
                var actor = Bridge.as(Bridge.createInstance(this.ActorType, [glue]), FVTTBridge.BridgeActor);

                return actor;
            },
            MakeActorSheet: function (glue) {
                var actorSheet = Bridge.as(Bridge.createInstance(this.ActorSheetType, [glue]), FVTTBridge.BridgeActorSheet);
                return actorSheet;
            },
            GetOptions: function (options) {
                return options;
            },
            SystemInit: function () {
                System.Console.WriteLine("SystemInit Called!");
                FVTTBridge.Bindings.Globals.CONFIG.Actor.entityClass = ActorGlue;
                var sheetOptions = { };
                sheetOptions.makeDefault = true;
                Actors.registerSheet("dnd5e", ActorSheetGlue, sheetOptions);
            }
        }
    });

    Bridge.define("FVTTBridge.Bindings.Globals", {
        statics: {
            fields: {
                CONFIG: null,
                GAME: null
            }
        }
    });

    Bridge.define("FVTTBridge.BridgeActor", {
        statics: {
            methods: {
                createTokenActor: function (baseActor, token) {
                    return ActorGlue.createTokenActor(baseActor, token);
                },
                fromToken: function (token) {
                    return ActorGlue.fromToken(token);
                }
            }
        },
        fields: {
            Glue: null
        },
        props: {
            config: {
                get: function () {
                    return this.Glue.config;
                }
            },
            apps: {
                get: function () {
                    return this.Glue.apps;
                }
            },
            compenidum: {
                get: function () {
                    return this.Glue.compendium;
                }
            },
            data: {
                get: function () {
                    return this.Glue.data;
                }
            },
            folder: {
                get: function () {
                    return this.Glue.folder;
                }
            },
            id: {
                get: function () {
                    return this.Glue.id;
                }
            },
            img: {
                get: function () {
                    return this.Glue.img;
                }
            },
            isPC: {
                get: function () {
                    return this.Glue.isPC;
                }
            },
            isToken: {
                get: function () {
                    return this.Glue.isToken;
                }
            },
            items: {
                get: function () {
                    return this.Glue.items;
                }
            },
            itemTypes: {
                get: function () {
                    return this.Glue.itemTypes;
                }
            },
            limited: {
                get: function () {
                    return this.Glue.limited;
                }
            },
            name: {
                get: function () {
                    return this.Glue.name;
                }
            },
            options: {
                get: function () {
                    return this.Glue.options;
                }
            },
            owner: {
                get: function () {
                    return this.Glue.owner;
                }
            },
            permission: {
                get: function () {
                    return this.Glue.permission;
                }
            },
            sheet: {
                get: function () {
                    return this.Glue.sheet;
                }
            },
            token: {
                get: function () {
                    return this.Glue.token;
                }
            },
            uuid: {
                get: function () {
                    return this.Glue.uuid;
                }
            },
            visible: {
                get: function () {
                    return this.Glue.visible;
                }
            }
        },
        ctors: {
            ctor: function (glue) {
                this.$initialize();
                this.Glue = glue;
            }
        },
        methods: {
            clone: function (createData, options) {
                return this.Glue.clone(createData, options);
            },
            createEmbeddedEntity: function (embeddedName, data, options) {
                return this.Glue.createEmbeddedEntity(embeddedName, data, options);
            },
            delete: function (optsToDelete) {
                return this.Glue.delete(optsToDelete);
            },
            deleteEmbeddedEntity: function (embeddedName, data, options) {
                return this.Glue.deleteEmbeddedEntity(embeddedName, data, options);
            },
            deleteOwnedItem: function (itemId, options) {
                return this.Glue.deleteOwnedItem(itemId, options);
            },
            exportToJSON: function () {
                this.Glue.exportToJSON();
            },
            getActiveTokens: function (linkedopt) {
                return this.Glue.getActiveTokens(linkedopt);
            },
            getEmbeddedCollection: function (embeddedName) {
                return this.Glue.getEmbeddedCollection(embeddedName);
            },
            getFlag: function (scope, key) {
                return this.Glue.getFlag(scope, key);
            },
            getOwnedItem: function (v) {
                return this.Glue.getOwnedItem(Bridge.unbox(v));
            },
            getRollData: function () {
                return this.Glue.getRollData();
            },
            getTokenImages: function () {
                return this.Glue.getTokenImages();
            },
            hasPerm: function (user, permission, exact) {
                return this.Glue.hasPerm(user, permission, exact);
            },
            importFromJSON: function (json) {
                return this.Glue.importFromJSON(json);
            },
            importFromJSONDialog: function () {
                return this.Glue.importFromJSONDialog();
            },
            importItemFromCollection: function (collection, entryId) {
                this.Glue.importItemFromCollection(collection, entryId);
            },
            modifyTokenAttribute: function (attribute, value, isDelta, isBar) {
                return this.Glue.modifyTokenAttribute(attribute, value, isDelta, isBar);
            },
            setFlag: function (scope, key, value) {
                return this.Glue.setFlag(scope, key, value);
            },
            sortRelative: function () {
                this.Glue.sortRelative();
            },
            toJSON: function () {
                return this.Glue.toJSON();
            },
            unsetFlag: function (scope, key) {
                return this.Glue.unsetFlag(scope, key);
            },
            update: function (data, options) {
                return this.Glue.update(data, options);
            },
            updateEmbeddedEntity: function (embeddedName, data, options) {
                return this.Glue.updateEmbeddedEntity(embeddedName, data, options);
            },
            updateOwnedItem: function (itemData, options) {
                return this.Glue.updateOwnedItem(itemData, options);
            },
            DeleteOwnedItem: function (v) {
                this.Glue.DeleteOwnedItem(Bridge.unbox(v));
            },
            PrepareData: function (data) {
                return data;
            },
            initialize: function () {
                this.Glue.initialize();
            },
            prepareData: function () {
                this.Glue.prepareData();
            },
            prepareEmbeddedEntities: function () {
                this.Glue.prepareEmbeddedEntities();
            },
            render: function (force, context) {
                this.Glue.render(force, context);
            }
        }
    });

    Bridge.define("FVTTBridge.BridgeActorSheet", {
        fields: {
            Glue: null
        },
        props: {
            Options: {
                get: function () {
                    return this.Glue.Options;
                }
            },
            Actor: {
                get: function () {
                    return this.Glue.ActorGlue.Actor;
                }
            }
        },
        ctors: {
            ctor: function () {
                this.$initialize();
            },
            $ctor1: function (glue) {
                this.$initialize();
                this.Glue = glue;
            }
        },
        methods: {
            ActivateListeners: function (html) {

            },
            Render: function (v) {
                this.Glue.Render(v);
            },
            getData: function () {
                return this.Glue.getData();
            }
        }
    });

    Bridge.define("FVTTBridge.FoundryModule", {
        statics: {
            fields: {
                Instances: null
            },
            ctors: {
                init: function () {
                    this.Instances = new (System.Collections.Generic.Dictionary$2(System.String,FVTTBridge.FoundryModule)).ctor();
                }
            }
        },
        props: {
            Instance: {
                get: function () {
                    return FVTTBridge.FoundryModule.Instances.getItem(Bridge.Reflection.getTypeFullName(Bridge.getType(this)));
                }
            }
        },
        ctors: {
            ctor: function () {
                this.$initialize();
                FVTTBridge.FoundryModule.Instances.add(Bridge.Reflection.getTypeFullName(Bridge.getType(this)), this);
                Hooks.on("init", Bridge.fn.cacheBind(this, this.ModuleInit));
                Hooks.on("ready", Bridge.fn.cacheBind(this, this.ModuleReady));
            }
        },
        methods: {
            GetOptions: function (options) {
                return options;
            },
            ModuleInit: function () {
                System.Console.WriteLine("ModuleInit Called!");

            },
            ModuleReady: function () {
                System.Console.WriteLine("ModuleReady Called!");
            }
        }
    });

    Bridge.define("FVTTBridge.Glue");
});

FVTTBridge.Bindings.Globals.CONFIG = Bridge.global["CONFIG"];
FVTTBridge.Bindings.Globals.GAME = Bridge.global["game"];

class ActorSheetGlue extends ActorSheet {
    constructor(actor,options) {
        super(actor,options);
        this.BridgeActorSheet = FVTTBridge.Bindings.FoundrySystem.Instance.MakeActorSheet(this);
      
    }
    

    static get defaultOptions() {
        var options = super.defaultOptions;
        options = FVTTBridge.Bindings.FoundrySystem.Instance.GetOptions(options);
        return options;
    }

    activateListeners(html) {
        super.activateListeners(html);
        this.BridgeActorSheet.ActivateListeners(html);
    }


}

class ActorGlue extends Actor {
    constructor(...args) {
        super(...args);
    }

    static prepareData() {
        super.prepareData();
        if (typeof this.Actor == undefined){
            this.Actor = FVTTBridge.Bindings.FoundrySystem.Instance.MakeActor(this);
        }
        this.data = this.Actor.PrepareData(this.data);
    }

}
            ;

//# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAiZmlsZSI6ICJGVlRUQnJpZGdlLmpzIiwKICAic291cmNlUm9vdCI6ICIiLAogICJzb3VyY2VzIjogWyJGb3VuZHJ5U3lzdGVtLmNzIiwiQnJpZGdlQWN0b3IuY3MiLCJCcmlkZ2VBY3RvclNoZWV0LmNzIiwiRm91bmRyeU1vZHVsZS5jcyIsIkdsdWUuY3MiXSwKICAibmFtZXMiOiBbIiJdLAogICJtYXBwaW5ncyI6ICI7Ozs7Ozs7Ozs7Ozs7Ozs7O29CQXNDZ0JBLE9BQU9BLEFBQU9BOzs7OztvQkFRZEEsT0FBT0EsQUFBT0E7Ozs7Ozs7Z0JBeUJsQkEsNkNBQXlCQTtnQkFDekJBLG1CQUFrQkEsQUFBUUE7Ozs7aUNBdEJEQTtnQkFFekJBLFlBQXFCQSxnQ0FBeUJBLGlCQUFVQTs7Z0JBRXhEQSxPQUFPQTs7c0NBRzRCQTtnQkFFbkNBLGlCQUE4QkEsZ0NBQXlCQSxzQkFBZUE7Z0JBQ3RFQSxPQUFPQTs7a0NBR3VCQTtnQkFFOUJBLE9BQU9BOzs7Z0JBWVBBO2dCQUVBQSx1REFBbUNBLEFBQU9BO2dCQUMxQ0EsbUJBQXVCQTtnQkFDdkJBO2dCQUNBQSw4QkFBOEJBLEFBQU9BLGdCQUFpQkE7Ozs7Ozs7Ozs7Ozs7Ozs7OzRDQzZHckJBLFdBQWlCQTtvQkFFbERBLE9BQU9BLDJCQUEyQkEsV0FBV0E7O3FDQUduQkE7b0JBRTFCQSxPQUFPQSxvQkFBb0JBOzs7Ozs7Ozs7O29CQXRLdkJBLE9BQU9BOzs7OztvQkFRUEEsT0FBT0E7Ozs7O29CQVFQQSxPQUFPQTs7Ozs7b0JBUVBBLE9BQU9BOzs7OztvQkFRUEEsT0FBT0E7Ozs7O29CQVFQQSxPQUFPQTs7Ozs7b0JBUVBBLE9BQU9BOzs7OztvQkFRUEEsT0FBT0E7Ozs7O29CQVFQQSxPQUFPQTs7Ozs7b0JBUVBBLE9BQU9BOzs7OztvQkFRUEEsT0FBT0E7Ozs7O29CQVFQQSxPQUFPQTs7Ozs7b0JBUVBBLE9BQU9BOzs7OztvQkFRUEEsT0FBT0E7Ozs7O29CQVFQQSxPQUFPQTs7Ozs7b0JBUVBBLE9BQU9BOzs7OztvQkFRUEEsT0FBT0E7Ozs7O29CQVFQQSxPQUFPQTs7Ozs7b0JBUVBBLE9BQU9BOzs7OztvQkFRUEEsT0FBT0E7Ozs7OzRCQW5LSUE7O2dCQUVmQSxZQUFPQTs7Ozs2QkFrTFVBLFlBQW9CQTtnQkFFckNBLE9BQU9BLGdCQUFXQSxZQUFZQTs7NENBR0VBLGNBQXFCQSxNQUNyREE7Z0JBRUFBLE9BQU9BLCtCQUEwQkEsY0FBY0EsTUFBTUE7OzhCQUduQ0E7Z0JBRWxCQSxPQUFPQSxpQkFBWUE7OzRDQUdhQSxjQUFxQkEsTUFDckRBO2dCQUVBQSxPQUFPQSwrQkFBMEJBLGNBQWNBLE1BQU1BOzt1Q0FHMUJBLFFBQWVBO2dCQUUxQ0EsT0FBT0EsMEJBQXFCQSxRQUFRQTs7O2dCQUtwQ0E7O3VDQUcyQkE7Z0JBRTNCQSxPQUFPQSwwQkFBcUJBOzs2Q0FHTUE7Z0JBRWxDQSxPQUFPQSxnQ0FBMkJBOzsrQkFHZkEsT0FBY0E7Z0JBRWpDQSxPQUFPQSxrQkFBYUEsT0FBT0E7O29DQUdOQTtnQkFFckJBLE9BQU9BLHVCQUFrQkE7OztnQkFLekJBLE9BQU9BOzs7Z0JBS1BBLE9BQU9BOzsrQkFHU0EsTUFBV0EsWUFBb0JBO2dCQUUvQ0EsT0FBT0Esa0JBQWFBLE1BQU1BLFlBQVlBOztzQ0FJWkE7Z0JBRTFCQSxPQUFPQSx5QkFBb0JBOzs7Z0JBSzNCQSxPQUFPQTs7Z0RBRzBCQSxZQUFtQkE7Z0JBRXBEQSxtQ0FBOEJBLFlBQVlBOzs0Q0FHVkEsV0FBa0JBLE9BQ2xEQSxTQUFjQTtnQkFFZEEsT0FBT0EsK0JBQTBCQSxXQUFXQSxPQUFPQSxTQUFTQTs7K0JBR3pDQSxPQUFjQSxLQUFZQTtnQkFFN0NBLE9BQU9BLGtCQUFhQSxPQUFPQSxLQUFLQTs7O2dCQUtoQ0E7OztnQkFLQUEsT0FBT0E7O2lDQUdjQSxPQUFjQTtnQkFFbkNBLE9BQU9BLG9CQUFlQSxPQUFPQTs7OEJBR1hBLE1BQWNBO2dCQUVoQ0EsT0FBT0EsaUJBQVlBLE1BQU1BOzs0Q0FHT0EsY0FDaENBLE1BQWNBO2dCQUVkQSxPQUFPQSwrQkFBMEJBLGNBQWNBLE1BQU1BOzt1Q0FHMUJBLFVBQWtCQTtnQkFFN0NBLE9BQU9BLDBCQUFxQkEsVUFBVUE7O3VDQVFkQTtnQkFFeEJBLDBCQUFxQkE7O21DQUtVQTtnQkFFL0JBLE9BQU9BOzs7Z0JBS1BBOzs7Z0JBS0FBOzs7Z0JBS0FBOzs4QkFHdUJBLE9BQVlBO2dCQUVuQ0EsaUJBQVlBLE9BQU9BOzs7Ozs7Ozs7Ozs7b0JDNVVmQSxPQUFPQTs7Ozs7b0JBUVBBLE9BQU9BOzs7Ozs7Ozs4QkFqQlNBOztnQkFFcEJBLFlBQU9BOzs7O3lDQW1CMkJBOzs7OEJBS25CQTtnQkFFZkEsaUJBQVlBOzs7Z0JBS1pBLE9BQU9BOzs7Ozs7Ozs7Ozs7cUNDdkNrREEsS0FBSUE7Ozs7Ozs7b0JBYXpEQSxPQUFPQSwyQ0FBVUE7Ozs7Ozs7Z0JBTXJCQSx1Q0FBNEJBLHlEQUF3QkE7Z0JBQ3BEQSxpQkFBaUJBLEFBQVFBO2dCQUN6QkEsa0JBQWtCQSxBQUFRQTs7OztrQ0FqQklBO2dCQUU5QkEsT0FBT0E7OztnQkFvQlBBOzs7O2dCQU1BQTs7Ozs7Ozs7QUg1QkFBLHFDQUFTQTtBQUNUQSxtQ0FBT0E7QUlGUEEiLAogICJzb3VyY2VzQ29udGVudCI6IFsidXNpbmcgQnJpZGdlO1xyXG51c2luZyBOZXd0b25zb2Z0Lkpzb247XHJcbnVzaW5nIFN5c3RlbTtcclxudXNpbmcgQnJpZGdlLkh0bWw1O1xyXG5cclxuXHJcbm5hbWVzcGFjZSBGVlRUQnJpZGdlLkJpbmRpbmdzXHJcbntcclxuICAgXHJcbiAgICBzdGF0aWMgcHVibGljIGNsYXNzIEdsb2JhbHNcclxuICAgIHtcclxuICAgICAgICBzdGF0aWMgcHVibGljICBkeW5hbWljIENPTkZJRztcclxuICAgICAgICBzdGF0aWMgcHVibGljIGR5bmFtaWMgR0FNRTtcclxuXHJcbiAgICAgICAgW0luaXQoSW5pdFBvc2l0aW9uLkJvdHRvbSldXHJcbiAgICAgICAgcHVibGljIHN0YXRpYyB2b2lkIFRvcEluaXQoKVxyXG4gICAgICAgIHtcclxuICAgICAgICAgICAgQ09ORklHID0gR2xvYmFsLkdldChcIkNPTkZJR1wiKTtcclxuICAgICAgICAgICAgR0FNRSA9IEdsb2JhbC5HZXQoXCJnYW1lXCIpO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBbT2JqZWN0TGl0ZXJhbF1cclxuICAgIHB1YmxpYyBjbGFzcyBSYXdKU09iamVjdFxyXG4gICAge1xyXG5cclxuICAgIH1cclxuXHJcbiAgICBwdWJsaWMgY2xhc3MgRm91bmRyeVN5c3RlbVxyXG4gICAge1xyXG4gICAgICAgIHByaXZhdGUgc3RhdGljIEZvdW5kcnlTeXN0ZW0gSW5zdGFuY2U7XHJcbiAgICAgXHJcblxyXG5cclxuICAgICAgICBwdWJsaWMgdmlydHVhbCBUeXBlIEFjdG9yVHlwZVxyXG4gICAgICAgIHtcclxuICAgICAgICAgICAgZ2V0XHJcbiAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgIHJldHVybiB0eXBlb2YoQnJpZGdlQWN0b3IpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBwdWJsaWMgdmlydHVhbCBUeXBlIEFjdG9yU2hlZXRUeXBlXHJcbiAgICAgICAge1xyXG4gICAgICAgICAgICBnZXRcclxuICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgcmV0dXJuIHR5cGVvZihCcmlkZ2VBY3RvclNoZWV0KTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgcHVibGljIEJyaWRnZUFjdG9yIE1ha2VBY3RvcihBY3RvckdsdWUgZ2x1ZSlcclxuICAgICAgICB7XHJcbiAgICAgICAgICAgIEJyaWRnZUFjdG9yIGFjdG9yID0gIEFjdGl2YXRvci5DcmVhdGVJbnN0YW5jZShBY3RvclR5cGUsZ2x1ZSkgYXMgQnJpZGdlQWN0b3I7XHJcblxyXG4gICAgICAgICAgICByZXR1cm4gYWN0b3I7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBwdWJsaWMgQnJpZGdlQWN0b3JTaGVldCBNYWtlQWN0b3JTaGVldChBY3RvclNoZWV0R2x1ZSBnbHVlKVxyXG4gICAgICAgIHtcclxuICAgICAgICAgICAgQnJpZGdlQWN0b3JTaGVldCBhY3RvclNoZWV0ID0gQWN0aXZhdG9yLkNyZWF0ZUluc3RhbmNlKEFjdG9yU2hlZXRUeXBlLGdsdWUpIGFzIEJyaWRnZUFjdG9yU2hlZXQ7XHJcbiAgICAgICAgICAgIHJldHVybiBhY3RvclNoZWV0O1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgcHVibGljIHZpcnR1YWwgZHluYW1pYyBHZXRPcHRpb25zKGR5bmFtaWMgb3B0aW9ucylcclxuICAgICAgICB7XHJcbiAgICAgICAgICAgIHJldHVybiBvcHRpb25zO1xyXG4gICAgICAgIH1cclxuXHJcblxyXG4gICAgICAgIHB1YmxpYyBGb3VuZHJ5U3lzdGVtKClcclxuICAgICAgICB7XHJcbiAgICAgICAgICAgIEZvdW5kcnlTeXN0ZW0uSW5zdGFuY2UgPSB0aGlzO1xyXG4gICAgICAgICAgICBIb29rcy5vbmNlKFwiaW5pdFwiLChBY3Rpb24pU3lzdGVtSW5pdCk7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBwcm90ZWN0ZWQgdmlydHVhbCB2b2lkIFN5c3RlbUluaXQoKVxyXG4gICAgICAgIHtcclxuICAgICAgICAgICAgQ29uc29sZS5Xcml0ZUxpbmUoXCJTeXN0ZW1Jbml0IENhbGxlZCFcIik7XHJcbiAgICAgICAgICAgIC8vQWN0b3JzLnJlZ2lzdGVyU2hlZXQoXCJjb3JlXCIsQWN0b3JTaGVldFR5cGUpO1xyXG4gICAgICAgICAgICBHbG9iYWxzLkNPTkZJRy5BY3Rvci5lbnRpdHlDbGFzcyA9IHR5cGVvZihBY3RvckdsdWUpO1xyXG4gICAgICAgICAgICBkeW5hbWljIHNoZWV0T3B0aW9ucyA9IG5ldyBSYXdKU09iamVjdCgpO1xyXG4gICAgICAgICAgICBzaGVldE9wdGlvbnMubWFrZURlZmF1bHQgPSB0cnVlO1xyXG4gICAgICAgICAgICBBY3RvcnMucmVnaXN0ZXJTaGVldChcImRuZDVlXCIsIHR5cGVvZihBY3RvclNoZWV0R2x1ZSksIHNoZWV0T3B0aW9ucyk7XHJcbiAgICAgICAgICAgIC8vSXRlbXMucmVnaXN0ZXJTaGVldChcImRuZDVlXCIsIFNpbXBsZUl0ZW1TaGVldCwgeyBtYWtlRGVmYXVsdDogdHJ1ZX0pO1xyXG4gICAgICAgIH1cclxuXHJcblxyXG4gICAgfVxyXG59XHJcbiIsInVzaW5nIFN5c3RlbTtcclxudXNpbmcgU3lzdGVtLkNvbGxlY3Rpb25zLkdlbmVyaWM7XHJcbnVzaW5nIEJyaWRnZTtcclxudXNpbmcgQnJpZGdlLmpRdWVyeTI7XHJcbnVzaW5nIFN5c3RlbTtcclxudXNpbmcgU3lzdGVtLkNvbGxlY3Rpb25zLkdlbmVyaWM7XHJcbnVzaW5nIFN5c3RlbS5Db2xsZWN0aW9ucy5PYmplY3RNb2RlbDtcclxudXNpbmcgU3lzdGVtLkxpbnE7XHJcbnVzaW5nIFN5c3RlbS5UZXh0O1xyXG51c2luZyBTeXN0ZW0uVGhyZWFkaW5nO1xyXG51c2luZyBTeXN0ZW0uVGhyZWFkaW5nLlRhc2tzO1xyXG51c2luZyBGVlRUQnJpZGdlLkJpbmRpbmdzO1xyXG5cclxubmFtZXNwYWNlIEZWVFRCcmlkZ2Vcclxue1xyXG5cclxuICAgIHB1YmxpYyBjbGFzcyBCcmlkZ2VBY3RvclxyXG4gICAge1xyXG4gICAgICAgIGludGVybmFsIEFjdG9yR2x1ZSBHbHVlIHsgZ2V0OyBzZXQ7IH1cclxuXHJcbiAgICAgIFxyXG4gICAgICAgIHB1YmxpYyBCcmlkZ2VBY3RvcihBY3RvckdsdWUgZ2x1ZSlcclxuICAgICAgICB7XHJcbiAgICAgICAgICAgIEdsdWUgPSBnbHVlO1xyXG4gICAgICAgIH1cclxuXHJcblxyXG4gICAgICAgICNyZWdpb24gQWNjZXNzb3JzXHJcbiAgICAgICAgcHVibGljIGR5bmFtaWMgY29uZmlnXHJcbiAgICAgICAge1xyXG4gICAgICAgICAgICBnZXRcclxuICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgcmV0dXJuIEdsdWUuY29uZmlnO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBwdWJsaWMgZHluYW1pYyBhcHBzXHJcbiAgICAgICAge1xyXG4gICAgICAgICAgICBnZXRcclxuICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgcmV0dXJuIEdsdWUuYXBwcztcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgcHVibGljIENvbXBlbmRpdW0gY29tcGVuaWR1bVxyXG4gICAgICAgIHtcclxuICAgICAgICAgICAgZ2V0XHJcbiAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgIHJldHVybiBHbHVlLmNvbXBlbmRpdW07XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIHB1YmxpYyBkeW5hbWljIGRhdGFcclxuICAgICAgICB7XHJcbiAgICAgICAgICAgIGdldFxyXG4gICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgICByZXR1cm4gR2x1ZS5kYXRhO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBwdWJsaWMgRm9sZGVyIGZvbGRlclxyXG4gICAgICAgIHtcclxuICAgICAgICAgICAgZ2V0XHJcbiAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgIHJldHVybiBHbHVlLmZvbGRlcjtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgcHVibGljIHN0cmluZyBpZFxyXG4gICAgICAgIHtcclxuICAgICAgICAgICAgZ2V0XHJcbiAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgIHJldHVybiBHbHVlLmlkO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBwdWJsaWMgc3RyaW5nIGltZ1xyXG4gICAgICAgIHtcclxuICAgICAgICAgICAgZ2V0XHJcbiAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgIHJldHVybiBHbHVlLmltZztcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgcHVibGljIGJvb2wgaXNQQ1xyXG4gICAgICAgIHtcclxuICAgICAgICAgICAgZ2V0XHJcbiAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgIHJldHVybiBHbHVlLmlzUEM7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIHB1YmxpYyBib29sIGlzVG9rZW5cclxuICAgICAgICB7XHJcbiAgICAgICAgICAgIGdldFxyXG4gICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgICByZXR1cm4gR2x1ZS5pc1Rva2VuO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBwdWJsaWMgRlZUVEJyaWRnZS5CaW5kaW5ncy5Db2xsZWN0aW9uIGl0ZW1zXHJcbiAgICAgICAge1xyXG4gICAgICAgICAgICBnZXRcclxuICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgcmV0dXJuIEdsdWUuaXRlbXM7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIHB1YmxpYyBGVlRUQnJpZGdlLkJpbmRpbmdzLkNvbGxlY3Rpb24gaXRlbVR5cGVzXHJcbiAgICAgICAge1xyXG4gICAgICAgICAgICBnZXRcclxuICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgcmV0dXJuIEdsdWUuaXRlbVR5cGVzO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBwdWJsaWMgYm9vbCBsaW1pdGVkXHJcbiAgICAgICAge1xyXG4gICAgICAgICAgICBnZXRcclxuICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgcmV0dXJuIEdsdWUubGltaXRlZDtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgcHVibGljIHN0cmluZyBuYW1lXHJcbiAgICAgICAge1xyXG4gICAgICAgICAgICBnZXRcclxuICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgcmV0dXJuIEdsdWUubmFtZTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgcHVibGljIGR5bmFtaWMgb3B0aW9uc1xyXG4gICAgICAgIHtcclxuICAgICAgICAgICAgZ2V0XHJcbiAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgIHJldHVybiBHbHVlLm9wdGlvbnM7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIHB1YmxpYyBib29sIG93bmVyXHJcbiAgICAgICAge1xyXG4gICAgICAgICAgICBnZXRcclxuICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgcmV0dXJuIEdsdWUub3duZXI7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIHB1YmxpYyBmbG9hdCBwZXJtaXNzaW9uXHJcbiAgICAgICAge1xyXG4gICAgICAgICAgICBnZXRcclxuICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgcmV0dXJuIEdsdWUucGVybWlzc2lvbjtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgcHVibGljIEJhc2VFbnRpdHlTaGVldCBzaGVldFxyXG4gICAgICAgIHtcclxuICAgICAgICAgICAgZ2V0XHJcbiAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgIHJldHVybiBHbHVlLnNoZWV0O1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBwdWJsaWMgVG9rZW4gdG9rZW5cclxuICAgICAgICB7XHJcbiAgICAgICAgICAgIGdldFxyXG4gICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgICByZXR1cm4gR2x1ZS50b2tlbjtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgcHVibGljIHN0cmluZyB1dWlkXHJcbiAgICAgICAge1xyXG4gICAgICAgICAgICBnZXRcclxuICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgcmV0dXJuIEdsdWUudXVpZDtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgcHVibGljIGJvb2wgdmlzaWJsZVxyXG4gICAgICAgIHtcclxuICAgICAgICAgICAgZ2V0XHJcbiAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgIHJldHVybiBHbHVlLnZpc2libGU7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICAgICAgI2VuZHJlZ2lvblxyXG5cclxuICAgICAgICAjcmVnaW9uIE1ldGhvZHNcclxuXHJcbiAgICAgICAgcHVibGljIHN0YXRpYyBBY3RvciBjcmVhdGVUb2tlbkFjdG9yKEFjdG9yIGJhc2VBY3RvciwgVG9rZW4gdG9rZW4pXHJcbiAgICAgICAge1xyXG4gICAgICAgICAgICByZXR1cm4gQWN0b3JHbHVlLmNyZWF0ZVRva2VuQWN0b3IoYmFzZUFjdG9yLCB0b2tlbik7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBwdWJsaWMgc3RhdGljIEFjdG9yIGZyb21Ub2tlbihUb2tlbiB0b2tlbilcclxuICAgICAgICB7XHJcbiAgICAgICAgICAgIHJldHVybiBBY3RvckdsdWUuZnJvbVRva2VuKHRva2VuKTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIHB1YmxpYyBQcm9taXNlIGNsb25lKGR5bmFtaWMgY3JlYXRlRGF0YSwgZHluYW1pYyBvcHRpb25zKVxyXG4gICAgICAgIHtcclxuICAgICAgICAgICAgcmV0dXJuIEdsdWUuY2xvbmUoY3JlYXRlRGF0YSwgb3B0aW9ucyk7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBwdWJsaWMgUHJvbWlzZSBjcmVhdGVFbWJlZGRlZEVudGl0eShzdHJpbmcgZW1iZWRkZWROYW1lLCBkeW5hbWljIGRhdGEsXHJcbiAgICAgICAgICAgIGR5bmFtaWMgb3B0aW9ucylcclxuICAgICAgICB7XHJcbiAgICAgICAgICAgIHJldHVybiBHbHVlLmNyZWF0ZUVtYmVkZGVkRW50aXR5KGVtYmVkZGVkTmFtZSwgZGF0YSwgb3B0aW9ucyk7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBwdWJsaWMgZHluYW1pYyBkZWxldGUoZHluYW1pYyBvcHRzVG9EZWxldGUpXHJcbiAgICAgICAge1xyXG4gICAgICAgICAgICByZXR1cm4gR2x1ZS5kZWxldGUob3B0c1RvRGVsZXRlKTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIHB1YmxpYyBQcm9taXNlIGRlbGV0ZUVtYmVkZGVkRW50aXR5KHN0cmluZyBlbWJlZGRlZE5hbWUsIGR5bmFtaWMgZGF0YSxcclxuICAgICAgICAgICAgZHluYW1pYyBvcHRpb25zKVxyXG4gICAgICAgIHtcclxuICAgICAgICAgICAgcmV0dXJuIEdsdWUuZGVsZXRlRW1iZWRkZWRFbnRpdHkoZW1iZWRkZWROYW1lLCBkYXRhLCBvcHRpb25zKTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIHB1YmxpYyBQcm9taXNlIGRlbGV0ZU93bmVkSXRlbShzdHJpbmcgaXRlbUlkLCBkeW5hbWljIG9wdGlvbnMpXHJcbiAgICAgICAge1xyXG4gICAgICAgICAgICByZXR1cm4gR2x1ZS5kZWxldGVPd25lZEl0ZW0oaXRlbUlkLCBvcHRpb25zKTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIHB1YmxpYyB2b2lkIGV4cG9ydFRvSlNPTigpXHJcbiAgICAgICAge1xyXG4gICAgICAgICAgICBHbHVlLmV4cG9ydFRvSlNPTigpO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgcHVibGljIFRva2VuW10gZ2V0QWN0aXZlVG9rZW5zKGJvb2wgbGlua2Vkb3B0KVxyXG4gICAgICAgIHtcclxuICAgICAgICAgICAgcmV0dXJuIEdsdWUuZ2V0QWN0aXZlVG9rZW5zKGxpbmtlZG9wdCk7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBwdWJsaWMgRW50aXR5W10gZ2V0RW1iZWRkZWRDb2xsZWN0aW9uKHN0cmluZyBlbWJlZGRlZE5hbWUpXHJcbiAgICAgICAge1xyXG4gICAgICAgICAgICByZXR1cm4gR2x1ZS5nZXRFbWJlZGRlZENvbGxlY3Rpb24oZW1iZWRkZWROYW1lKTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIHB1YmxpYyBkeW5hbWljIGdldEZsYWcoc3RyaW5nIHNjb3BlLCBzdHJpbmcga2V5KVxyXG4gICAgICAgIHtcclxuICAgICAgICAgICAgcmV0dXJuIEdsdWUuZ2V0RmxhZyhzY29wZSwga2V5KTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIHB1YmxpYyBJdGVtIGdldE93bmVkSXRlbShvYmplY3QgdilcclxuICAgICAgICB7XHJcbiAgICAgICAgICAgIHJldHVybiBHbHVlLmdldE93bmVkSXRlbSh2KTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIHB1YmxpYyBkeW5hbWljIGdldFJvbGxEYXRhKClcclxuICAgICAgICB7XHJcbiAgICAgICAgICAgIHJldHVybiBHbHVlLmdldFJvbGxEYXRhKCk7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBwdWJsaWMgUHJvbWlzZSBnZXRUb2tlbkltYWdlcygpXHJcbiAgICAgICAge1xyXG4gICAgICAgICAgICByZXR1cm4gR2x1ZS5nZXRUb2tlbkltYWdlcygpO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgcHVibGljIGJvb2wgaGFzUGVybShVc2VyIHVzZXIsIGR5bmFtaWMgcGVybWlzc2lvbiwgYm9vbCBleGFjdClcclxuICAgICAgICB7XHJcbiAgICAgICAgICAgIHJldHVybiBHbHVlLmhhc1Blcm0odXNlciwgcGVybWlzc2lvbiwgZXhhY3QpO1xyXG4gICAgICAgIH1cclxuXHJcblxyXG4gICAgICAgIHB1YmxpYyBQcm9taXNlIGltcG9ydEZyb21KU09OKHN0cmluZyBqc29uKVxyXG4gICAgICAgIHtcclxuICAgICAgICAgICAgcmV0dXJuIEdsdWUuaW1wb3J0RnJvbUpTT04oanNvbik7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBwdWJsaWMgUHJvbWlzZSBpbXBvcnRGcm9tSlNPTkRpYWxvZygpXHJcbiAgICAgICAge1xyXG4gICAgICAgICAgICByZXR1cm4gR2x1ZS5pbXBvcnRGcm9tSlNPTkRpYWxvZygpO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgcHVibGljIHZvaWQgaW1wb3J0SXRlbUZyb21Db2xsZWN0aW9uKHN0cmluZyBjb2xsZWN0aW9uLCBzdHJpbmcgZW50cnlJZClcclxuICAgICAgICB7XHJcbiAgICAgICAgICAgIEdsdWUuaW1wb3J0SXRlbUZyb21Db2xsZWN0aW9uKGNvbGxlY3Rpb24sIGVudHJ5SWQpO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgcHVibGljIFByb21pc2UgbW9kaWZ5VG9rZW5BdHRyaWJ1dGUoc3RyaW5nIGF0dHJpYnV0ZSwgZmxvYXQgdmFsdWUsXHJcbiAgICAgICAgICAgIGJvb2wgaXNEZWx0YSwgYm9vbCBpc0JhcilcclxuICAgICAgICB7XHJcbiAgICAgICAgICAgIHJldHVybiBHbHVlLm1vZGlmeVRva2VuQXR0cmlidXRlKGF0dHJpYnV0ZSwgdmFsdWUsIGlzRGVsdGEsIGlzQmFyKTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIHB1YmxpYyBQcm9taXNlIHNldEZsYWcoc3RyaW5nIHNjb3BlLCBzdHJpbmcga2V5LCBkeW5hbWljIHZhbHVlKVxyXG4gICAgICAgIHtcclxuICAgICAgICAgICAgcmV0dXJuIEdsdWUuc2V0RmxhZyhzY29wZSwga2V5LCB2YWx1ZSk7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBwdWJsaWMgdm9pZCBzb3J0UmVsYXRpdmUoKVxyXG4gICAgICAgIHtcclxuICAgICAgICAgICAgR2x1ZS5zb3J0UmVsYXRpdmUoKTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIHB1YmxpYyBkeW5hbWljIHRvSlNPTigpXHJcbiAgICAgICAge1xyXG4gICAgICAgICAgICByZXR1cm4gR2x1ZS50b0pTT04oKTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIHB1YmxpYyBQcm9taXNlIHVuc2V0RmxhZyhzdHJpbmcgc2NvcGUsIHN0cmluZyBrZXkpXHJcbiAgICAgICAge1xyXG4gICAgICAgICAgICByZXR1cm4gR2x1ZS51bnNldEZsYWcoc2NvcGUsIGtleSk7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBwdWJsaWMgUHJvbWlzZSB1cGRhdGUoZHluYW1pYyBkYXRhLCBkeW5hbWljIG9wdGlvbnMpXHJcbiAgICAgICAge1xyXG4gICAgICAgICAgICByZXR1cm4gR2x1ZS51cGRhdGUoZGF0YSwgb3B0aW9ucyk7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBwdWJsaWMgUHJvbWlzZSB1cGRhdGVFbWJlZGRlZEVudGl0eShzdHJpbmcgZW1iZWRkZWROYW1lLFxyXG4gICAgICAgICAgICBkeW5hbWljIGRhdGEsIGR5bmFtaWMgb3B0aW9ucylcclxuICAgICAgICB7XHJcbiAgICAgICAgICAgIHJldHVybiBHbHVlLnVwZGF0ZUVtYmVkZGVkRW50aXR5KGVtYmVkZGVkTmFtZSwgZGF0YSwgb3B0aW9ucyk7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBwdWJsaWMgUHJvbWlzZSB1cGRhdGVPd25lZEl0ZW0oZHluYW1pYyBpdGVtRGF0YSwgZHluYW1pYyBvcHRpb25zKVxyXG4gICAgICAgIHtcclxuICAgICAgICAgICAgcmV0dXJuIEdsdWUudXBkYXRlT3duZWRJdGVtKGl0ZW1EYXRhLCBvcHRpb25zKTtcclxuICAgICAgICB9XHJcblxyXG5cclxuXHJcblxyXG5cclxuXHJcbiAgICAgICAgcHVibGljIHZvaWQgRGVsZXRlT3duZWRJdGVtKG9iamVjdCB2KVxyXG4gICAgICAgIHtcclxuICAgICAgICAgICAgR2x1ZS5EZWxldGVPd25lZEl0ZW0odik7XHJcbiAgICAgICAgfVxyXG4gICAgICAgICNlbmRyZWdpb25cclxuXHJcbiAgICAgICAgI3JlZ2lvbiBDYWxsYmFja3NcclxuICAgICAgICBwdWJsaWMgdmlydHVhbCBkeW5hbWljIFByZXBhcmVEYXRhKGR5bmFtaWMgZGF0YSlcclxuICAgICAgICB7XHJcbiAgICAgICAgICAgIHJldHVybiBkYXRhO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgcHVibGljIHZpcnR1YWwgdm9pZCBpbml0aWFsaXplKClcclxuICAgICAgICB7XHJcbiAgICAgICAgICAgIEdsdWUuaW5pdGlhbGl6ZSgpO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgcHVibGljIHZpcnR1YWwgdm9pZCBwcmVwYXJlRGF0YSgpXHJcbiAgICAgICAge1xyXG4gICAgICAgICAgICBHbHVlLnByZXBhcmVEYXRhKCk7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBwdWJsaWMgdmlydHVhbCB2b2lkIHByZXBhcmVFbWJlZGRlZEVudGl0aWVzKClcclxuICAgICAgICB7XHJcbiAgICAgICAgICAgIEdsdWUucHJlcGFyZUVtYmVkZGVkRW50aXRpZXMoKTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIHB1YmxpYyB2aXJ0dWFsIHZvaWQgcmVuZGVyKGJvb2wgZm9yY2UsIGR5bmFtaWMgY29udGV4dClcclxuICAgICAgICB7XHJcbiAgICAgICAgICAgIEdsdWUucmVuZGVyKGZvcmNlLCBjb250ZXh0KTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgICNlbmRyZWdpb25cclxuICAgIH1cclxufVxyXG4iLCJ1c2luZyBCcmlkZ2U7XHJcbnVzaW5nIE5ld3RvbnNvZnQuSnNvbjtcclxudXNpbmcgU3lzdGVtO1xyXG51c2luZyBCcmlkZ2UuSHRtbDU7XHJcbnVzaW5nIEJyaWRnZS5qUXVlcnkyO1xyXG51c2luZyBGVlRUQnJpZGdlLkJpbmRpbmdzO1xyXG5cclxubmFtZXNwYWNlIEZWVFRCcmlkZ2Vcclxue1xyXG5cclxuXHJcbiAgICBwdWJsaWMgY2xhc3MgQnJpZGdlQWN0b3JTaGVldFxyXG4gICAge1xyXG4gICAgICAgIGludGVybmFsIEFjdG9yU2hlZXRHbHVlIEdsdWVcclxuICAgICAgICB7XHJcbiAgICAgICAgICAgIGdldDsgc2V0O1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgcHVibGljIEJyaWRnZUFjdG9yU2hlZXQoKSB7IH1cclxuICAgICAgICBwdWJsaWMgQnJpZGdlQWN0b3JTaGVldChBY3RvclNoZWV0R2x1ZSBnbHVlKVxyXG4gICAgICAgIHtcclxuICAgICAgICAgICAgR2x1ZSA9IGdsdWU7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBwdWJsaWMgZHluYW1pYyBPcHRpb25zXHJcbiAgICAgICAge1xyXG4gICAgICAgICAgICBnZXRcclxuICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgcmV0dXJuIEdsdWUuT3B0aW9ucztcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgcHVibGljIEFjdG9yIEFjdG9yXHJcbiAgICAgICAge1xyXG4gICAgICAgICAgICBnZXRcclxuICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgcmV0dXJuIEdsdWUuQWN0b3JHbHVlLkFjdG9yO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBwdWJsaWMgdmlydHVhbCB2b2lkIEFjdGl2YXRlTGlzdGVuZXJzKGpRdWVyeSBodG1sKVxyXG4gICAgICAgIHtcclxuXHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBwdWJsaWMgdm9pZCBSZW5kZXIoYm9vbCB2KVxyXG4gICAgICAgIHtcclxuICAgICAgICAgICAgR2x1ZS5SZW5kZXIodik7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBwdWJsaWMgZHluYW1pYyBnZXREYXRhKClcclxuICAgICAgICB7XHJcbiAgICAgICAgICAgIHJldHVybiBHbHVlLmdldERhdGEoKTtcclxuICAgICAgICB9XHJcblxyXG4gICAgfVxyXG59XHJcbiIsInVzaW5nIEJyaWRnZTtcclxudXNpbmcgTmV3dG9uc29mdC5Kc29uO1xyXG51c2luZyBTeXN0ZW07XHJcbnVzaW5nIEJyaWRnZS5IdG1sNTtcclxudXNpbmcgRlZUVEJyaWRnZS5CaW5kaW5ncztcclxudXNpbmcgU3lzdGVtLkNvbGxlY3Rpb25zLkdlbmVyaWM7XHJcblxyXG5uYW1lc3BhY2UgRlZUVEJyaWRnZVxyXG57XHJcblxyXG5cclxuICAgIHB1YmxpYyBjbGFzcyBGb3VuZHJ5TW9kdWxlXHJcbiAgICB7XHJcbiAgICAgICAgcHJpdmF0ZSBzdGF0aWMgRGljdGlvbmFyeTxzdHJpbmcsIEZvdW5kcnlNb2R1bGU+IEluc3RhbmNlcyA9IG5ldyBEaWN0aW9uYXJ5PHN0cmluZywgRm91bmRyeU1vZHVsZT4oKTtcclxuXHJcblxyXG4gICAgICAgIFxyXG4gICAgICAgIHB1YmxpYyB2aXJ0dWFsIGR5bmFtaWMgR2V0T3B0aW9ucyhkeW5hbWljIG9wdGlvbnMpXHJcbiAgICAgICAge1xyXG4gICAgICAgICAgICByZXR1cm4gb3B0aW9ucztcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIHB1YmxpYyBGb3VuZHJ5TW9kdWxlIEluc3RhbmNlXHJcbiAgICAgICAge1xyXG4gICAgICAgICAgICBnZXRcclxuICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgcmV0dXJuIEluc3RhbmNlc1t0aGlzLkdldFR5cGUoKS5GdWxsTmFtZV07XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIHB1YmxpYyBGb3VuZHJ5TW9kdWxlKClcclxuICAgICAgICB7XHJcbiAgICAgICAgICAgIEZvdW5kcnlNb2R1bGUuSW5zdGFuY2VzLkFkZCh0aGlzLkdldFR5cGUoKS5GdWxsTmFtZSx0aGlzKTtcclxuICAgICAgICAgICAgSG9va3Mub24oXCJpbml0XCIsIChBY3Rpb24pTW9kdWxlSW5pdCk7XHJcbiAgICAgICAgICAgIEhvb2tzLm9uKFwicmVhZHlcIiwgKEFjdGlvbilNb2R1bGVSZWFkeSk7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBwcm90ZWN0ZWQgdmlydHVhbCB2b2lkIE1vZHVsZUluaXQoKVxyXG4gICAgICAgIHtcclxuICAgICAgICAgICAgQ29uc29sZS5Xcml0ZUxpbmUoXCJNb2R1bGVJbml0IENhbGxlZCFcIik7XHJcbiAgICAgICAgICAgIFxyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgcHJvdGVjdGVkIHZpcnR1YWwgdm9pZCBNb2R1bGVSZWFkeSgpXHJcbiAgICAgICAge1xyXG4gICAgICAgICAgICBDb25zb2xlLldyaXRlTGluZShcIk1vZHVsZVJlYWR5IENhbGxlZCFcIik7XHJcbiAgICAgICAgfVxyXG5cclxuXHJcbiAgICB9XHJcbn0iLCJ1c2luZyBCcmlkZ2U7XHJcbnVzaW5nIFN5c3RlbTtcclxudXNpbmcgU3lzdGVtLkNvbGxlY3Rpb25zLkdlbmVyaWM7XHJcbnVzaW5nIFN5c3RlbS5MaW5xO1xyXG51c2luZyBTeXN0ZW0uVGV4dDtcclxudXNpbmcgU3lzdGVtLlRocmVhZGluZy5UYXNrcztcclxuXHJcbm5hbWVzcGFjZSBGVlRUQnJpZGdlXHJcbntcclxuICAgIFxyXG5cclxuICAgIGNsYXNzIEdsdWVcclxuICAgIHtcclxuICAgICAgICBbSW5pdChJbml0UG9zaXRpb24uQm90dG9tKV1cclxuICAgICAgICBwdWJsaWMgc3RhdGljIHZvaWQgQm90dG9tKClcclxuICAgICAgICB7XHJcbiAgICAgICAgICAgIFNjcmlwdC5Xcml0ZShAXCJcclxuY2xhc3MgQWN0b3JTaGVldEdsdWUgZXh0ZW5kcyBBY3RvclNoZWV0IHtcclxuICAgIGNvbnN0cnVjdG9yKGFjdG9yLG9wdGlvbnMpIHtcclxuICAgICAgICBzdXBlcihhY3RvcixvcHRpb25zKTtcclxuICAgICAgICB0aGlzLkJyaWRnZUFjdG9yU2hlZXQgPSBGVlRUQnJpZGdlLkJpbmRpbmdzLkZvdW5kcnlTeXN0ZW0uSW5zdGFuY2UuTWFrZUFjdG9yU2hlZXQodGhpcyk7XHJcbiAgICAgIFxyXG4gICAgfVxyXG4gICAgXHJcblxyXG4gICAgc3RhdGljIGdldCBkZWZhdWx0T3B0aW9ucygpIHtcclxuICAgICAgICB2YXIgb3B0aW9ucyA9IHN1cGVyLmRlZmF1bHRPcHRpb25zO1xyXG4gICAgICAgIG9wdGlvbnMgPSBGVlRUQnJpZGdlLkJpbmRpbmdzLkZvdW5kcnlTeXN0ZW0uSW5zdGFuY2UuR2V0T3B0aW9ucyhvcHRpb25zKTtcclxuICAgICAgICByZXR1cm4gb3B0aW9ucztcclxuICAgIH1cclxuXHJcbiAgICBhY3RpdmF0ZUxpc3RlbmVycyhodG1sKSB7XHJcbiAgICAgICAgc3VwZXIuYWN0aXZhdGVMaXN0ZW5lcnMoaHRtbCk7XHJcbiAgICAgICAgdGhpcy5CcmlkZ2VBY3RvclNoZWV0LkFjdGl2YXRlTGlzdGVuZXJzKGh0bWwpO1xyXG4gICAgfVxyXG5cclxuXHJcbn1cclxuXHJcbmNsYXNzIEFjdG9yR2x1ZSBleHRlbmRzIEFjdG9yIHtcclxuICAgIGNvbnN0cnVjdG9yKC4uLmFyZ3MpIHtcclxuICAgICAgICBzdXBlciguLi5hcmdzKTtcclxuICAgIH1cclxuXHJcbiAgICBzdGF0aWMgcHJlcGFyZURhdGEoKSB7XHJcbiAgICAgICAgc3VwZXIucHJlcGFyZURhdGEoKTtcclxuICAgICAgICBpZiAodHlwZW9mIHRoaXMuQWN0b3IgPT0gdW5kZWZpbmVkKXtcclxuICAgICAgICAgICAgdGhpcy5BY3RvciA9IEZWVFRCcmlkZ2UuQmluZGluZ3MuRm91bmRyeVN5c3RlbS5JbnN0YW5jZS5NYWtlQWN0b3IodGhpcyk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHRoaXMuZGF0YSA9IHRoaXMuQWN0b3IuUHJlcGFyZURhdGEodGhpcy5kYXRhKTtcclxuICAgIH1cclxuXHJcbn1cclxuICAgICAgICAgICAgXCIpO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxufVxyXG4iXQp9Cg==
